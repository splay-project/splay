require"base"
require"chunk2"

local chunk_number = 1

function chunky()
	return 1 + chunk_number
end

events.run(function()
	events.periodic(1,chunky())
	events.periodic(1,function() print("chunk1") end)
end)
