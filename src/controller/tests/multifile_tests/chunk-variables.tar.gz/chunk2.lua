local chunk_number = 2

function chunky()
	return 2 + chunk_number
end

events.run(function()
	events.periodic(2,chunky())
	events.periodic(2,function() print("chunk2") end)
end)
