require"base"
require"chunk2"

events.run(function()
	events.periodic(1,chunky())
	events.periodic(1,function() print("chunk1") end)
end)
