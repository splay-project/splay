function chunky()
	return "chunk2"
end

events.thread(function()
	events.periodic(2,chunky())
	events.periodic(2,function() print("chunk2") end)
end)

events.thread()
