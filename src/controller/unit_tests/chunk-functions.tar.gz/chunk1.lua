require"base"
require"chunk2"

function chunky()
	return "chunk" + chunk_number
end

events.run(function()
	events.periodic(1,chunky())
	events.periodic(1,function() print("chunk1") end)
end)
