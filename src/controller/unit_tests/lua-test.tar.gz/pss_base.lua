require"splay.base"
rpc = require"splay.rpc"
misc = require "splay.misc"
crypto = require "crypto"
rpc.server(job.me.port)
me = {}   -- me = {peer, age, id}
me.peer = job.me  -- job.me = peer = {ip = "127.0.0.1", port = 20000}
M = 32
function compute_hash(o)
	return tonumber(string.sub(crypto.evp.new("sha1"):digest(o), 1, M/4), 16)
end
me.age = 0
--me.id = compute_hash(table.concat({tostring(job.me.ip),":",tostring(job.me.port)}))
me.id = job.position
me.payload = {}
PSS = {
	view = {},
	view_copy = {},
	-- c = PSS_VIEW_SIZE,
	c = 10,
	--exch = PSS_SHUFFLE_SIZE,
	exch = 5,
	H = 1,
	-- S = math.floor(PSS_VIEW_SIZE/ 2 + 0.5) - 1,
}
