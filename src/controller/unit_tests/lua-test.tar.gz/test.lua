require"pss_base"

function main()
	
		PSS.set_parameters(60, 5, 3)  -- running time, view_size , cycle period
		PSS.startPSS()
		



end		
events.thread(main)  
events.loop()