require"splay.events"

function chunky()
	return "chunk" + chunk_number
end

events.run(function()
	events.periodic(2,chunky())
	events.periodic(2,function() print("chunk2") end)
end)
