module ChurnLang
  include Treetop::Runtime

  def root
    @root || :root
  end

  module Root0
			def desc
				nil
			end
  end

  def _nt_root
    start_index = index
    if node_cache[:root].has_key?(index)
      cached = node_cache[:root][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    r1 = _nt_action_line
    if r1
      r0 = r1
    else
      r2 = _nt_comment_c_style
      if r2
        r0 = r2
      else
        s3, i3 = [], index
        loop do
          r4 = _nt_space
          if r4
            s3 << r4
          else
            break
          end
        end
        r3 = instantiate_node(SyntaxNode,input, i3...index, s3)
        r3.extend(Root0)
        if r3
          r0 = r3
        else
          self.index = i0
          r0 = nil
        end
      end
    end

    node_cache[:root][start_index] = r0

    return r0
  end

  module ActionLine0
    def t
      elements[0]
    end

    def space
      elements[1]
    end

    def a
      elements[2]
    end

    def space
      elements[3]
    end

    def c
      elements[4]
    end
  end

  module ActionLine1
			def desc
				Line.new(t.desc,a.desc,c.desc)
			end
  end

  module ActionLine2
    def t
      elements[0]
    end

    def space
      elements[1]
    end

    def a
      elements[2]
    end
  end

  module ActionLine3
			def desc
				Line.new(t.desc,a.desc,nil)
			end
  end

  def _nt_action_line
    start_index = index
    if node_cache[:action_line].has_key?(index)
      cached = node_cache[:action_line][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    r2 = _nt_timing
    s1 << r2
    if r2
      r3 = _nt_space
      s1 << r3
      if r3
        r4 = _nt_action
        s1 << r4
        if r4
          r5 = _nt_space
          s1 << r5
          if r5
            r6 = _nt_add_churn
            s1 << r6
          end
        end
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(ActionLine0)
      r1.extend(ActionLine1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i7, s7 = index, []
      r8 = _nt_timing
      s7 << r8
      if r8
        r9 = _nt_space
        s7 << r9
        if r9
          r10 = _nt_action
          s7 << r10
        end
      end
      if s7.last
        r7 = instantiate_node(SyntaxNode,input, i7...index, s7)
        r7.extend(ActionLine2)
        r7.extend(ActionLine3)
      else
        self.index = i7
        r7 = nil
      end
      if r7
        r0 = r7
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:action_line][start_index] = r0

    return r0
  end

  module Timing0
    def space
      elements[1]
    end

    def a1
      elements[2]
    end
  end

  module Timing1
			def desc
				InstantTiming.new(a1.value)
			end
  end

  module Timing2
    def space
      elements[1]
    end

    def a1
      elements[2]
    end

    def space
      elements[3]
    end

    def space
      elements[5]
    end

    def a2
      elements[6]
    end
  end

  module Timing3
			def desc
				PeriodTiming.new(a1.value,a2.value)
			end
  end

  def _nt_timing
    start_index = index
    if node_cache[:timing].has_key?(index)
      cached = node_cache[:timing][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    if input.index("at", index) == index
      r2 = instantiate_node(SyntaxNode,input, index...(index + 2))
      @index += 2
    else
      terminal_parse_failure("at")
      r2 = nil
    end
    s1 << r2
    if r2
      r3 = _nt_space
      s1 << r3
      if r3
        r4 = _nt_additive_time
        s1 << r4
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(Timing0)
      r1.extend(Timing1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i5, s5 = index, []
      if input.index("from", index) == index
        r6 = instantiate_node(SyntaxNode,input, index...(index + 4))
        @index += 4
      else
        terminal_parse_failure("from")
        r6 = nil
      end
      s5 << r6
      if r6
        r7 = _nt_space
        s5 << r7
        if r7
          r8 = _nt_additive_time
          s5 << r8
          if r8
            r9 = _nt_space
            s5 << r9
            if r9
              if input.index("to", index) == index
                r10 = instantiate_node(SyntaxNode,input, index...(index + 2))
                @index += 2
              else
                terminal_parse_failure("to")
                r10 = nil
              end
              s5 << r10
              if r10
                r11 = _nt_space
                s5 << r11
                if r11
                  r12 = _nt_additive_time
                  s5 << r12
                end
              end
            end
          end
        end
      end
      if s5.last
        r5 = instantiate_node(SyntaxNode,input, i5...index, s5)
        r5.extend(Timing2)
        r5.extend(Timing3)
      else
        self.index = i5
        r5 = nil
      end
      if r5
        r0 = r5
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:timing][start_index] = r0

    return r0
  end

  module AdditiveTime0
    def op1
      elements[0]
    end

    def opt_space
      elements[1]
    end

    def opt_space
      elements[3]
    end

    def op2
      elements[4]
    end
  end

  module AdditiveTime1
			def value
				op1.value + op2.value
			end
  end

  module AdditiveTime2
    def op1
      elements[0]
    end

    def opt_space
      elements[1]
    end

    def opt_space
      elements[3]
    end

    def op2
      elements[4]
    end
  end

  module AdditiveTime3
			def value
				op1.value - op2.value
			end
  end

  def _nt_additive_time
    start_index = index
    if node_cache[:additive_time].has_key?(index)
      cached = node_cache[:additive_time][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    r2 = _nt_multitive_time
    s1 << r2
    if r2
      r3 = _nt_opt_space
      s1 << r3
      if r3
        i4 = index
        if input.index('+', index) == index
          r5 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          terminal_parse_failure('+')
          r5 = nil
        end
        if r5
          r4 = r5
        else
          if input.index('and', index) == index
            r6 = instantiate_node(SyntaxNode,input, index...(index + 3))
            @index += 3
          else
            terminal_parse_failure('and')
            r6 = nil
          end
          if r6
            r4 = r6
          else
            if input.index(',', index) == index
              r7 = instantiate_node(SyntaxNode,input, index...(index + 1))
              @index += 1
            else
              terminal_parse_failure(',')
              r7 = nil
            end
            if r7
              r4 = r7
            else
              self.index = i4
              r4 = nil
            end
          end
        end
        s1 << r4
        if r4
          r8 = _nt_opt_space
          s1 << r8
          if r8
            r9 = _nt_additive_time
            s1 << r9
          end
        end
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(AdditiveTime0)
      r1.extend(AdditiveTime1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i10, s10 = index, []
      r11 = _nt_multitive_time
      s10 << r11
      if r11
        r12 = _nt_opt_space
        s10 << r12
        if r12
          if input.index('-', index) == index
            r13 = instantiate_node(SyntaxNode,input, index...(index + 1))
            @index += 1
          else
            terminal_parse_failure('-')
            r13 = nil
          end
          s10 << r13
          if r13
            r14 = _nt_opt_space
            s10 << r14
            if r14
              r15 = _nt_additive_time
              s10 << r15
            end
          end
        end
      end
      if s10.last
        r10 = instantiate_node(SyntaxNode,input, i10...index, s10)
        r10.extend(AdditiveTime2)
        r10.extend(AdditiveTime3)
      else
        self.index = i10
        r10 = nil
      end
      if r10
        r0 = r10
      else
        r16 = _nt_multitive_time
        if r16
          r0 = r16
        else
          self.index = i0
          r0 = nil
        end
      end
    end

    node_cache[:additive_time][start_index] = r0

    return r0
  end

  module MultitiveTime0
    def op1
      elements[0]
    end

    def opt_space
      elements[1]
    end

    def opt_space
      elements[3]
    end

    def op2
      elements[4]
    end
  end

  module MultitiveTime1
			def value
				op1.value * op2.value 
			end
  end

  def _nt_multitive_time
    start_index = index
    if node_cache[:multitive_time].has_key?(index)
      cached = node_cache[:multitive_time][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    r2 = _nt_primary_time
    s1 << r2
    if r2
      r3 = _nt_opt_space
      s1 << r3
      if r3
        if input.index('*', index) == index
          r4 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          terminal_parse_failure('*')
          r4 = nil
        end
        s1 << r4
        if r4
          r5 = _nt_opt_space
          s1 << r5
          if r5
            r6 = _nt_multitive_time
            s1 << r6
          end
        end
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(MultitiveTime0)
      r1.extend(MultitiveTime1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      r7 = _nt_primary_time
      if r7
        r0 = r7
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:multitive_time][start_index] = r0

    return r0
  end

  module PrimaryTime0
    def opt_space
      elements[1]
    end

    def op1
      elements[2]
    end

    def opt_space
      elements[3]
    end

  end

  module PrimaryTime1
			def value
				op1.value
			end
  end

  def _nt_primary_time
    start_index = index
    if node_cache[:primary_time].has_key?(index)
      cached = node_cache[:primary_time][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    if input.index('(', index) == index
      r2 = instantiate_node(SyntaxNode,input, index...(index + 1))
      @index += 1
    else
      terminal_parse_failure('(')
      r2 = nil
    end
    s1 << r2
    if r2
      r3 = _nt_opt_space
      s1 << r3
      if r3
        r4 = _nt_additive_time
        s1 << r4
        if r4
          r5 = _nt_opt_space
          s1 << r5
          if r5
            if input.index(')', index) == index
              r6 = instantiate_node(SyntaxNode,input, index...(index + 1))
              @index += 1
            else
              terminal_parse_failure(')')
              r6 = nil
            end
            s1 << r6
          end
        end
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(PrimaryTime0)
      r1.extend(PrimaryTime1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      r7 = _nt_time
      if r7
        r0 = r7
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:primary_time][start_index] = r0

    return r0
  end

  module Time0
    def n
      elements[0]
    end

    def opt_space
      elements[1]
    end

    def t
      elements[2]
    end
  end

  module Time1
			def value
				n.value * t.multiplier
			end
  end

  def _nt_time
    start_index = index
    if node_cache[:time].has_key?(index)
      cached = node_cache[:time][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0, s0 = index, []
    r1 = _nt_multitive
    s0 << r1
    if r1
      r2 = _nt_opt_space
      s0 << r2
      if r2
        r3 = _nt_time_type
        s0 << r3
      end
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Time0)
      r0.extend(Time1)
    else
      self.index = i0
      r0 = nil
    end

    node_cache[:time][start_index] = r0

    return r0
  end

  module TimeType0
  end

  module TimeType1
			def multiplier
				1
			end
  end

  module TimeType2
  end

  module TimeType3
			def multiplier
				60
			end
  end

  module TimeType4
  end

  module TimeType5
			def multiplier
				60*60
			end
  end

  module TimeType6
  end

  module TimeType7
			def multiplier
				60*60*24
			end
  end

  def _nt_time_type
    start_index = index
    if node_cache[:time_type].has_key?(index)
      cached = node_cache[:time_type][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    if input.index(Regexp.new('[sS]'), index) == index
      r2 = instantiate_node(SyntaxNode,input, index...(index + 1))
      @index += 1
    else
      r2 = nil
    end
    s1 << r2
    if r2
      r4 = _nt_seconds
      if r4
        r3 = r4
      else
        r3 = instantiate_node(SyntaxNode,input, index...index)
      end
      s1 << r3
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(TimeType0)
      r1.extend(TimeType1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i5, s5 = index, []
      if input.index(Regexp.new('[mM]'), index) == index
        r6 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        r6 = nil
      end
      s5 << r6
      if r6
        r8 = _nt_minutes
        if r8
          r7 = r8
        else
          r7 = instantiate_node(SyntaxNode,input, index...index)
        end
        s5 << r7
      end
      if s5.last
        r5 = instantiate_node(SyntaxNode,input, i5...index, s5)
        r5.extend(TimeType2)
        r5.extend(TimeType3)
      else
        self.index = i5
        r5 = nil
      end
      if r5
        r0 = r5
      else
        i9, s9 = index, []
        if input.index(Regexp.new('[hH]'), index) == index
          r10 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          r10 = nil
        end
        s9 << r10
        if r10
          r12 = _nt_hours
          if r12
            r11 = r12
          else
            r11 = instantiate_node(SyntaxNode,input, index...index)
          end
          s9 << r11
        end
        if s9.last
          r9 = instantiate_node(SyntaxNode,input, i9...index, s9)
          r9.extend(TimeType4)
          r9.extend(TimeType5)
        else
          self.index = i9
          r9 = nil
        end
        if r9
          r0 = r9
        else
          i13, s13 = index, []
          if input.index(Regexp.new('[dD]'), index) == index
            r14 = instantiate_node(SyntaxNode,input, index...(index + 1))
            @index += 1
          else
            r14 = nil
          end
          s13 << r14
          if r14
            r16 = _nt_days
            if r16
              r15 = r16
            else
              r15 = instantiate_node(SyntaxNode,input, index...index)
            end
            s13 << r15
          end
          if s13.last
            r13 = instantiate_node(SyntaxNode,input, i13...index, s13)
            r13.extend(TimeType6)
            r13.extend(TimeType7)
          else
            self.index = i13
            r13 = nil
          end
          if r13
            r0 = r13
          else
            self.index = i0
            r0 = nil
          end
        end
      end
    end

    node_cache[:time_type][start_index] = r0

    return r0
  end

  module Seconds0
  end

  def _nt_seconds
    start_index = index
    if node_cache[:seconds].has_key?(index)
      cached = node_cache[:seconds][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0, s0 = index, []
    if input.index('econd', index) == index
      r1 = instantiate_node(SyntaxNode,input, index...(index + 5))
      @index += 5
    else
      terminal_parse_failure('econd')
      r1 = nil
    end
    s0 << r1
    if r1
      if input.index('s', index) == index
        r3 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        terminal_parse_failure('s')
        r3 = nil
      end
      if r3
        r2 = r3
      else
        r2 = instantiate_node(SyntaxNode,input, index...index)
      end
      s0 << r2
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Seconds0)
    else
      self.index = i0
      r0 = nil
    end

    node_cache[:seconds][start_index] = r0

    return r0
  end

  module Minutes0
  end

  def _nt_minutes
    start_index = index
    if node_cache[:minutes].has_key?(index)
      cached = node_cache[:minutes][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0, s0 = index, []
    if input.index('inute', index) == index
      r1 = instantiate_node(SyntaxNode,input, index...(index + 5))
      @index += 5
    else
      terminal_parse_failure('inute')
      r1 = nil
    end
    s0 << r1
    if r1
      if input.index('s', index) == index
        r3 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        terminal_parse_failure('s')
        r3 = nil
      end
      if r3
        r2 = r3
      else
        r2 = instantiate_node(SyntaxNode,input, index...index)
      end
      s0 << r2
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Minutes0)
    else
      self.index = i0
      r0 = nil
    end

    node_cache[:minutes][start_index] = r0

    return r0
  end

  module Hours0
  end

  def _nt_hours
    start_index = index
    if node_cache[:hours].has_key?(index)
      cached = node_cache[:hours][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0, s0 = index, []
    if input.index('our', index) == index
      r1 = instantiate_node(SyntaxNode,input, index...(index + 3))
      @index += 3
    else
      terminal_parse_failure('our')
      r1 = nil
    end
    s0 << r1
    if r1
      if input.index('s', index) == index
        r3 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        terminal_parse_failure('s')
        r3 = nil
      end
      if r3
        r2 = r3
      else
        r2 = instantiate_node(SyntaxNode,input, index...index)
      end
      s0 << r2
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Hours0)
    else
      self.index = i0
      r0 = nil
    end

    node_cache[:hours][start_index] = r0

    return r0
  end

  module Days0
  end

  def _nt_days
    start_index = index
    if node_cache[:days].has_key?(index)
      cached = node_cache[:days][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0, s0 = index, []
    if input.index('ay', index) == index
      r1 = instantiate_node(SyntaxNode,input, index...(index + 2))
      @index += 2
    else
      terminal_parse_failure('ay')
      r1 = nil
    end
    s0 << r1
    if r1
      if input.index('s', index) == index
        r3 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        terminal_parse_failure('s')
        r3 = nil
      end
      if r3
        r2 = r3
      else
        r2 = instantiate_node(SyntaxNode,input, index...index)
      end
      s0 << r2
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Days0)
    else
      self.index = i0
      r0 = nil
    end

    node_cache[:days][start_index] = r0

    return r0
  end

  module Action0
    def space
      elements[0]
    end

    def space
      elements[2]
    end
  end

  module Action1
    def space
      elements[1]
    end

    def space
      elements[3]
    end

    def q
      elements[6]
    end
  end

  module Action2
			def desc
				SetMaximumPopulationAction.new(q.desc)
			end
  end

  module Action3
    def space
      elements[0]
    end

    def space
      elements[2]
    end
  end

  module Action4
    def space
      elements[1]
    end

    def q
      elements[4]
    end
  end

  module Action5
			def desc
				SetReplacementRatioAction.new(q.desc)
			end
  end

  module Action6
    def space
      elements[1]
    end

    def q
      elements[2]
    end
  end

  module Action7
			def desc
				IncreaseAction.new(q.desc)
			end
  end

  module Action8
			def desc
				NullAction.new()
			end
  end

  module Action9
    def space
      elements[1]
    end

    def q
      elements[2]
    end
  end

  module Action10
			def desc
				DecreaseAction.new(q.desc)
			end
  end

  module Action11
			def desc
				StopAction.new()
			end
  end

  def _nt_action
    start_index = index
    if node_cache[:action].has_key?(index)
      cached = node_cache[:action][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    if input.index("set", index) == index
      r2 = instantiate_node(SyntaxNode,input, index...(index + 3))
      @index += 3
    else
      terminal_parse_failure("set")
      r2 = nil
    end
    s1 << r2
    if r2
      r3 = _nt_space
      s1 << r3
      if r3
        i4 = index
        if input.index("maximum", index) == index
          r5 = instantiate_node(SyntaxNode,input, index...(index + 7))
          @index += 7
        else
          terminal_parse_failure("maximum")
          r5 = nil
        end
        if r5
          r4 = r5
        else
          if input.index("max", index) == index
            r6 = instantiate_node(SyntaxNode,input, index...(index + 3))
            @index += 3
          else
            terminal_parse_failure("max")
            r6 = nil
          end
          if r6
            r4 = r6
          else
            self.index = i4
            r4 = nil
          end
        end
        s1 << r4
        if r4
          r7 = _nt_space
          s1 << r7
          if r7
            i8 = index
            if input.index("population", index) == index
              r9 = instantiate_node(SyntaxNode,input, index...(index + 10))
              @index += 10
            else
              terminal_parse_failure("population")
              r9 = nil
            end
            if r9
              r8 = r9
            else
              if input.index("pop", index) == index
                r10 = instantiate_node(SyntaxNode,input, index...(index + 3))
                @index += 3
              else
                terminal_parse_failure("pop")
                r10 = nil
              end
              if r10
                r8 = r10
              else
                self.index = i8
                r8 = nil
              end
            end
            s1 << r8
            if r8
              i11 = index
              i12, s12 = index, []
              r13 = _nt_space
              s12 << r13
              if r13
                if input.index("to", index) == index
                  r14 = instantiate_node(SyntaxNode,input, index...(index + 2))
                  @index += 2
                else
                  terminal_parse_failure("to")
                  r14 = nil
                end
                s12 << r14
                if r14
                  r15 = _nt_space
                  s12 << r15
                end
              end
              if s12.last
                r12 = instantiate_node(SyntaxNode,input, i12...index, s12)
                r12.extend(Action0)
              else
                self.index = i12
                r12 = nil
              end
              if r12
                r11 = r12
              else
                r16 = _nt_space
                if r16
                  r11 = r16
                else
                  self.index = i11
                  r11 = nil
                end
              end
              s1 << r11
              if r11
                r17 = _nt_quantity
                s1 << r17
              end
            end
          end
        end
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(Action1)
      r1.extend(Action2)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i18, s18 = index, []
      if input.index("set", index) == index
        r19 = instantiate_node(SyntaxNode,input, index...(index + 3))
        @index += 3
      else
        terminal_parse_failure("set")
        r19 = nil
      end
      s18 << r19
      if r19
        r20 = _nt_space
        s18 << r20
        if r20
          i21 = index
          if input.index("replacement ratio", index) == index
            r22 = instantiate_node(SyntaxNode,input, index...(index + 17))
            @index += 17
          else
            terminal_parse_failure("replacement ratio")
            r22 = nil
          end
          if r22
            r21 = r22
          else
            if input.index("repratio", index) == index
              r23 = instantiate_node(SyntaxNode,input, index...(index + 8))
              @index += 8
            else
              terminal_parse_failure("repratio")
              r23 = nil
            end
            if r23
              r21 = r23
            else
              if input.index("rep.ratio", index) == index
                r24 = instantiate_node(SyntaxNode,input, index...(index + 9))
                @index += 9
              else
                terminal_parse_failure("rep.ratio")
                r24 = nil
              end
              if r24
                r21 = r24
              else
                self.index = i21
                r21 = nil
              end
            end
          end
          s18 << r21
          if r21
            i25 = index
            i26, s26 = index, []
            r27 = _nt_space
            s26 << r27
            if r27
              if input.index("to", index) == index
                r28 = instantiate_node(SyntaxNode,input, index...(index + 2))
                @index += 2
              else
                terminal_parse_failure("to")
                r28 = nil
              end
              s26 << r28
              if r28
                r29 = _nt_space
                s26 << r29
              end
            end
            if s26.last
              r26 = instantiate_node(SyntaxNode,input, i26...index, s26)
              r26.extend(Action3)
            else
              self.index = i26
              r26 = nil
            end
            if r26
              r25 = r26
            else
              r30 = _nt_space
              if r30
                r25 = r30
              else
                self.index = i25
                r25 = nil
              end
            end
            s18 << r25
            if r25
              r31 = _nt_quantity_relative_only
              s18 << r31
            end
          end
        end
      end
      if s18.last
        r18 = instantiate_node(SyntaxNode,input, i18...index, s18)
        r18.extend(Action4)
        r18.extend(Action5)
      else
        self.index = i18
        r18 = nil
      end
      if r18
        r0 = r18
      else
        i32, s32 = index, []
        i33 = index
        if input.index("join", index) == index
          r34 = instantiate_node(SyntaxNode,input, index...(index + 4))
          @index += 4
        else
          terminal_parse_failure("join")
          r34 = nil
        end
        if r34
          r33 = r34
        else
          if input.index("add", index) == index
            r35 = instantiate_node(SyntaxNode,input, index...(index + 3))
            @index += 3
          else
            terminal_parse_failure("add")
            r35 = nil
          end
          if r35
            r33 = r35
          else
            if input.index("increase", index) == index
              r36 = instantiate_node(SyntaxNode,input, index...(index + 8))
              @index += 8
            else
              terminal_parse_failure("increase")
              r36 = nil
            end
            if r36
              r33 = r36
            else
              if input.index("inc", index) == index
                r37 = instantiate_node(SyntaxNode,input, index...(index + 3))
                @index += 3
              else
                terminal_parse_failure("inc")
                r37 = nil
              end
              if r37
                r33 = r37
              else
                self.index = i33
                r33 = nil
              end
            end
          end
        end
        s32 << r33
        if r33
          r38 = _nt_space
          s32 << r38
          if r38
            r39 = _nt_quantity
            s32 << r39
          end
        end
        if s32.last
          r32 = instantiate_node(SyntaxNode,input, i32...index, s32)
          r32.extend(Action6)
          r32.extend(Action7)
        else
          self.index = i32
          r32 = nil
        end
        if r32
          r0 = r32
        else
          i40 = index
          if input.index("const", index) == index
            r41 = instantiate_node(SyntaxNode,input, index...(index + 5))
            @index += 5
          else
            terminal_parse_failure("const")
            r41 = nil
          end
          if r41
            r40 = r41
            r40.extend(Action8)
          else
            if input.index("keep", index) == index
              r42 = instantiate_node(SyntaxNode,input, index...(index + 4))
              @index += 4
            else
              terminal_parse_failure("keep")
              r42 = nil
            end
            if r42
              r40 = r42
              r40.extend(Action8)
            else
              self.index = i40
              r40 = nil
            end
          end
          if r40
            r0 = r40
          else
            i43, s43 = index, []
            i44 = index
            if input.index("leave", index) == index
              r45 = instantiate_node(SyntaxNode,input, index...(index + 5))
              @index += 5
            else
              terminal_parse_failure("leave")
              r45 = nil
            end
            if r45
              r44 = r45
            else
              if input.index("remove", index) == index
                r46 = instantiate_node(SyntaxNode,input, index...(index + 6))
                @index += 6
              else
                terminal_parse_failure("remove")
                r46 = nil
              end
              if r46
                r44 = r46
              else
                if input.index("decrease", index) == index
                  r47 = instantiate_node(SyntaxNode,input, index...(index + 8))
                  @index += 8
                else
                  terminal_parse_failure("decrease")
                  r47 = nil
                end
                if r47
                  r44 = r47
                else
                  if input.index("dec", index) == index
                    r48 = instantiate_node(SyntaxNode,input, index...(index + 3))
                    @index += 3
                  else
                    terminal_parse_failure("dec")
                    r48 = nil
                  end
                  if r48
                    r44 = r48
                  else
                    self.index = i44
                    r44 = nil
                  end
                end
              end
            end
            s43 << r44
            if r44
              r49 = _nt_space
              s43 << r49
              if r49
                r50 = _nt_quantity
                s43 << r50
              end
            end
            if s43.last
              r43 = instantiate_node(SyntaxNode,input, i43...index, s43)
              r43.extend(Action9)
              r43.extend(Action10)
            else
              self.index = i43
              r43 = nil
            end
            if r43
              r0 = r43
            else
              i51 = index
              if input.index("end", index) == index
                r52 = instantiate_node(SyntaxNode,input, index...(index + 3))
                @index += 3
              else
                terminal_parse_failure("end")
                r52 = nil
              end
              if r52
                r51 = r52
                r51.extend(Action11)
              else
                if input.index("stop", index) == index
                  r53 = instantiate_node(SyntaxNode,input, index...(index + 4))
                  @index += 4
                else
                  terminal_parse_failure("stop")
                  r53 = nil
                end
                if r53
                  r51 = r53
                  r51.extend(Action11)
                else
                  self.index = i51
                  r51 = nil
                end
              end
              if r51
                r0 = r51
              else
                self.index = i0
                r0 = nil
              end
            end
          end
        end
      end
    end

    node_cache[:action][start_index] = r0

    return r0
  end

  module AddChurn0
    def space
      elements[1]
    end

    def q
      elements[2]
    end

    def opt_space
      elements[3]
    end

    def opt_space
      elements[5]
    end

    def t
      elements[6]
    end
  end

  module AddChurn1
			def desc
				AdditionalChurn.new(q.desc,true,t.value)
			end
  end

  module AddChurn2
    def space
      elements[1]
    end

    def q
      elements[2]
    end
  end

  module AddChurn3
			def desc
				AdditionalChurn.new(q.desc,false,nil)
			end
  end

  def _nt_add_churn
    start_index = index
    if node_cache[:add_churn].has_key?(index)
      cached = node_cache[:add_churn][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    if input.index('churn', index) == index
      r2 = instantiate_node(SyntaxNode,input, index...(index + 5))
      @index += 5
    else
      terminal_parse_failure('churn')
      r2 = nil
    end
    s1 << r2
    if r2
      r3 = _nt_space
      s1 << r3
      if r3
        r4 = _nt_quantity
        s1 << r4
        if r4
          r5 = _nt_opt_space
          s1 << r5
          if r5
            i6 = index
            if input.index('/', index) == index
              r7 = instantiate_node(SyntaxNode,input, index...(index + 1))
              @index += 1
            else
              terminal_parse_failure('/')
              r7 = nil
            end
            if r7
              r6 = r7
            else
              if input.index("per", index) == index
                r8 = instantiate_node(SyntaxNode,input, index...(index + 3))
                @index += 3
              else
                terminal_parse_failure("per")
                r8 = nil
              end
              if r8
                r6 = r8
              else
                if input.index("each", index) == index
                  r9 = instantiate_node(SyntaxNode,input, index...(index + 4))
                  @index += 4
                else
                  terminal_parse_failure("each")
                  r9 = nil
                end
                if r9
                  r6 = r9
                else
                  self.index = i6
                  r6 = nil
                end
              end
            end
            s1 << r6
            if r6
              r10 = _nt_opt_space
              s1 << r10
              if r10
                r11 = _nt_additive_time
                s1 << r11
              end
            end
          end
        end
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(AddChurn0)
      r1.extend(AddChurn1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i12, s12 = index, []
      if input.index('churn', index) == index
        r13 = instantiate_node(SyntaxNode,input, index...(index + 5))
        @index += 5
      else
        terminal_parse_failure('churn')
        r13 = nil
      end
      s12 << r13
      if r13
        r14 = _nt_space
        s12 << r14
        if r14
          r15 = _nt_quantity
          s12 << r15
        end
      end
      if s12.last
        r12 = instantiate_node(SyntaxNode,input, i12...index, s12)
        r12.extend(AddChurn2)
        r12.extend(AddChurn3)
      else
        self.index = i12
        r12 = nil
      end
      if r12
        r0 = r12
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:add_churn][start_index] = r0

    return r0
  end

  module QuantityRelativeOnly0
    def op1
      elements[0]
    end

    def opt_space
      elements[1]
    end

  end

  module QuantityRelativeOnly1
			def desc
				Quantity.new(op1.value,true)
			end
  end

  def _nt_quantity_relative_only
    start_index = index
    if node_cache[:quantity_relative_only].has_key?(index)
      cached = node_cache[:quantity_relative_only][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0, s0 = index, []
    r1 = _nt_additive
    s0 << r1
    if r1
      r2 = _nt_opt_space
      s0 << r2
      if r2
        if input.index('%', index) == index
          r3 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          terminal_parse_failure('%')
          r3 = nil
        end
        s0 << r3
      end
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(QuantityRelativeOnly0)
      r0.extend(QuantityRelativeOnly1)
    else
      self.index = i0
      r0 = nil
    end

    node_cache[:quantity_relative_only][start_index] = r0

    return r0
  end

  module Quantity0
    def op1
      elements[0]
    end

    def opt_space
      elements[1]
    end

  end

  module Quantity1
			def desc
				Quantity.new(op1.value,true)
			end
  end

  module Quantity2
			def desc
				Quantity.new(value,false)
			end
  end

  def _nt_quantity
    start_index = index
    if node_cache[:quantity].has_key?(index)
      cached = node_cache[:quantity][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    r2 = _nt_additive
    s1 << r2
    if r2
      r3 = _nt_opt_space
      s1 << r3
      if r3
        if input.index('%', index) == index
          r4 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          terminal_parse_failure('%')
          r4 = nil
        end
        s1 << r4
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(Quantity0)
      r1.extend(Quantity1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      r5 = _nt_additive
      r5.extend(Quantity2)
      if r5
        r0 = r5
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:quantity][start_index] = r0

    return r0
  end

  module Additive0
    def op1
      elements[0]
    end

    def op2
      elements[2]
    end
  end

  module Additive1
			def value
				op1.value + op2.value
			end
  end

  module Additive2
    def op1
      elements[0]
    end

    def op2
      elements[2]
    end
  end

  module Additive3
			def value
				op1.value - op2.value
			end
  end

  def _nt_additive
    start_index = index
    if node_cache[:additive].has_key?(index)
      cached = node_cache[:additive][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    r2 = _nt_multitive
    s1 << r2
    if r2
      if input.index('+', index) == index
        r3 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        terminal_parse_failure('+')
        r3 = nil
      end
      s1 << r3
      if r3
        r4 = _nt_additive
        s1 << r4
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(Additive0)
      r1.extend(Additive1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i5, s5 = index, []
      r6 = _nt_multitive
      s5 << r6
      if r6
        if input.index('-', index) == index
          r7 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          terminal_parse_failure('-')
          r7 = nil
        end
        s5 << r7
        if r7
          r8 = _nt_additive
          s5 << r8
        end
      end
      if s5.last
        r5 = instantiate_node(SyntaxNode,input, i5...index, s5)
        r5.extend(Additive2)
        r5.extend(Additive3)
      else
        self.index = i5
        r5 = nil
      end
      if r5
        r0 = r5
      else
        r9 = _nt_multitive
        if r9
          r0 = r9
        else
          self.index = i0
          r0 = nil
        end
      end
    end

    node_cache[:additive][start_index] = r0

    return r0
  end

  module Multitive0
    def op1
      elements[0]
    end

    def op2
      elements[2]
    end
  end

  module Multitive1
			def value
				op1.value * op2.value
			end
  end

  def _nt_multitive
    start_index = index
    if node_cache[:multitive].has_key?(index)
      cached = node_cache[:multitive][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    r2 = _nt_primary
    s1 << r2
    if r2
      if input.index('*', index) == index
        r3 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        terminal_parse_failure('*')
        r3 = nil
      end
      s1 << r3
      if r3
        r4 = _nt_multitive
        s1 << r4
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(Multitive0)
      r1.extend(Multitive1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      r5 = _nt_primary
      if r5
        r0 = r5
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:multitive][start_index] = r0

    return r0
  end

  module Primary0
    def op1
      elements[1]
    end

  end

  module Primary1
			def value
				op1.value
			end
  end

  def _nt_primary
    start_index = index
    if node_cache[:primary].has_key?(index)
      cached = node_cache[:primary][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    if input.index('(', index) == index
      r2 = instantiate_node(SyntaxNode,input, index...(index + 1))
      @index += 1
    else
      terminal_parse_failure('(')
      r2 = nil
    end
    s1 << r2
    if r2
      r3 = _nt_additive
      s1 << r3
      if r3
        if input.index(')', index) == index
          r4 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          terminal_parse_failure(')')
          r4 = nil
        end
        s1 << r4
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(Primary0)
      r1.extend(Primary1)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      r5 = _nt_number
      if r5
        r0 = r5
      else
        self.index = i0
        r0 = nil
      end
    end

    node_cache[:primary][start_index] = r0

    return r0
  end

  module Number0
 
			def value 
				text_value.to_i 
			end
  end

  def _nt_number
    start_index = index
    if node_cache[:number].has_key?(index)
      cached = node_cache[:number][index]
      @index = cached.interval.end if cached
      return cached
    end

    s0, i0 = [], index
    loop do
      if input.index(Regexp.new('[0-9]'), index) == index
        r1 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        r1 = nil
      end
      if r1
        s0 << r1
      else
        break
      end
    end
    r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
    r0.extend(Number0)

    node_cache[:number][start_index] = r0

    return r0
  end

  def _nt_space
    start_index = index
    if node_cache[:space].has_key?(index)
      cached = node_cache[:space][index]
      @index = cached.interval.end if cached
      return cached
    end

    s0, i0 = [], index
    loop do
      if input.index(Regexp.new('[ \\t\\r]'), index) == index
        r1 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        r1 = nil
      end
      if r1
        s0 << r1
      else
        break
      end
    end
    if s0.empty?
      self.index = i0
      r0 = nil
    else
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
    end

    node_cache[:space][start_index] = r0

    return r0
  end

  def _nt_opt_space
    start_index = index
    if node_cache[:opt_space].has_key?(index)
      cached = node_cache[:opt_space][index]
      @index = cached.interval.end if cached
      return cached
    end

    s0, i0 = [], index
    loop do
      if input.index(Regexp.new('[ \\t\\r]'), index) == index
        r1 = instantiate_node(SyntaxNode,input, index...(index + 1))
        @index += 1
      else
        r1 = nil
      end
      if r1
        s0 << r1
      else
        break
      end
    end
    r0 = instantiate_node(SyntaxNode,input, i0...index, s0)

    node_cache[:opt_space][start_index] = r0

    return r0
  end

  module CommentCStyle0
  end

  module CommentCStyle1
  end

  module CommentCStyle2
			def desc
				nil
			end
  end

  module CommentCStyle3
  end

  module CommentCStyle4
			def desc
				nil
			end
  end

  module CommentCStyle5
  end

  module CommentCStyle6
			def desc
				nil
			end
  end

  def _nt_comment_c_style
    start_index = index
    if node_cache[:comment_c_style].has_key?(index)
      cached = node_cache[:comment_c_style][index]
      @index = cached.interval.end if cached
      return cached
    end

    i0 = index
    i1, s1 = index, []
    if input.index('/*', index) == index
      r2 = instantiate_node(SyntaxNode,input, index...(index + 2))
      @index += 2
    else
      terminal_parse_failure('/*')
      r2 = nil
    end
    s1 << r2
    if r2
      s3, i3 = [], index
      loop do
        i4, s4 = index, []
        i5 = index
        if input.index('*/', index) == index
          r6 = instantiate_node(SyntaxNode,input, index...(index + 2))
          @index += 2
        else
          terminal_parse_failure('*/')
          r6 = nil
        end
        if r6
          r5 = nil
        else
          self.index = i5
          r5 = instantiate_node(SyntaxNode,input, index...index)
        end
        s4 << r5
        if r5
          if index < input_length
            r7 = instantiate_node(SyntaxNode,input, index...(index + 1))
            @index += 1
          else
            terminal_parse_failure("any character")
            r7 = nil
          end
          s4 << r7
        end
        if s4.last
          r4 = instantiate_node(SyntaxNode,input, i4...index, s4)
          r4.extend(CommentCStyle0)
        else
          self.index = i4
          r4 = nil
        end
        if r4
          s3 << r4
        else
          break
        end
      end
      r3 = instantiate_node(SyntaxNode,input, i3...index, s3)
      s1 << r3
      if r3
        if input.index('*/', index) == index
          r8 = instantiate_node(SyntaxNode,input, index...(index + 2))
          @index += 2
        else
          terminal_parse_failure('*/')
          r8 = nil
        end
        s1 << r8
      end
    end
    if s1.last
      r1 = instantiate_node(SyntaxNode,input, i1...index, s1)
      r1.extend(CommentCStyle1)
      r1.extend(CommentCStyle2)
    else
      self.index = i1
      r1 = nil
    end
    if r1
      r0 = r1
    else
      i9, s9 = index, []
      if input.index('//', index) == index
        r10 = instantiate_node(SyntaxNode,input, index...(index + 2))
        @index += 2
      else
        terminal_parse_failure('//')
        r10 = nil
      end
      s9 << r10
      if r10
        s11, i11 = [], index
        loop do
          if index < input_length
            r12 = instantiate_node(SyntaxNode,input, index...(index + 1))
            @index += 1
          else
            terminal_parse_failure("any character")
            r12 = nil
          end
          if r12
            s11 << r12
          else
            break
          end
        end
        r11 = instantiate_node(SyntaxNode,input, i11...index, s11)
        s9 << r11
      end
      if s9.last
        r9 = instantiate_node(SyntaxNode,input, i9...index, s9)
        r9.extend(CommentCStyle3)
        r9.extend(CommentCStyle4)
      else
        self.index = i9
        r9 = nil
      end
      if r9
        r0 = r9
      else
        i13, s13 = index, []
        if input.index('#', index) == index
          r14 = instantiate_node(SyntaxNode,input, index...(index + 1))
          @index += 1
        else
          terminal_parse_failure('#')
          r14 = nil
        end
        s13 << r14
        if r14
          s15, i15 = [], index
          loop do
            if index < input_length
              r16 = instantiate_node(SyntaxNode,input, index...(index + 1))
              @index += 1
            else
              terminal_parse_failure("any character")
              r16 = nil
            end
            if r16
              s15 << r16
            else
              break
            end
          end
          r15 = instantiate_node(SyntaxNode,input, i15...index, s15)
          s13 << r15
        end
        if s13.last
          r13 = instantiate_node(SyntaxNode,input, i13...index, s13)
          r13.extend(CommentCStyle5)
          r13.extend(CommentCStyle6)
        else
          self.index = i13
          r13 = nil
        end
        if r13
          r0 = r13
        else
          self.index = i0
          r0 = nil
        end
      end
    end

    node_cache[:comment_c_style][start_index] = r0

    return r0
  end

end

class ChurnLangParser < Treetop::Runtime::CompiledParser
  include ChurnLang
end

