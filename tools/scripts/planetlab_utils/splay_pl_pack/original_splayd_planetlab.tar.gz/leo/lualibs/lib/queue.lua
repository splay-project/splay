--module(..., package.seeall)
module("queue")

--[[
Simple dequeue module. Code adapter from http://www.lua.org/pil/11.4.html
To operate in strictly FIFO mode, always:
pushfirst(q,obj)
removelast(q)
]]
function new()
    return {first = 0, last = -1,size=0}
end
function pushfirst (list, value)
 local first = list.first - 1
 list.first = first
 list[first] = value
 list.size=list.size+1
end

function pushlast(list, value)
 local last = list.last + 1
 list.last = last
 list[last] = value
 list.size=list.size+1
end

function popfirst(list)
 local first = list.first
 if first > list.last then error("list is empty") end
 local value = list[first]
 list[first] = nil        -- to allow garbage collection
 list.first = first + 1
 list.size=list.size-1
 return value
end

function poplast(list)
 local last = list.last
 if list.first > last then error("list is empty") end
 local value = list[last]
 list[last] = nil         -- to allow garbage collection
 list.last = last - 1
 list.size=list.size-1
 return value
end

function size(list)
	return list.size
end