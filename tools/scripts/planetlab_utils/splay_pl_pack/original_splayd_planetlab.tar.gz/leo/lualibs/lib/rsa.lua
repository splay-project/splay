local bn = require"bn"
local misc = require"splay.misc"
local string= require"string"
local io=require"io"
local crypto = require"crypto"
local math=math
local os=require"os"
local tonumber=tonumber
local assert=assert
local print=print
local error=error
local table=table
--module(..., package.seeall)
module("rsa")

local hex = {};
for i = 0, 255 do
  hex[string.char(i)] = string.format("%02X", i);
end

function string2hex(s)
  assert(s,"String2hex arg was null")
  return string.gsub(s, ".", hex)
end

function hex2string(x)
	local s = {}
	for i=1,#x,2 do
		s[#s+1]=string.char(tonumber(x:sub(i,i),16)*16+tonumber(x:sub(i+1,i+1),16))
	end
	return table.concat(s)
end

function string2bn(s)
       local x=bn.number(0)
       for i=1,#s do
               x=256*x+s:byte(i)
       end
       return x
end

function bn2string(x)
	if x:iszero() then
		return ""
	else
		local r
		x,r=bn.divmod(x,256)
		return bn2string(x)..string.char(r:tonumber())
       end
end

function hex2bn(s)
	local x=bn.number(0)
	for i=1,#s do
		x=16*x+tonumber(s:sub(i,i),16)
	end
	return x
end

function bn2hex(n) return bn.tohex(n) end

function encrypt(m,e,n) return bn.powmod(m,e,n) end
function decrypt(x,d,n) return bn.powmod(x,d,n) end


function pad_hex_with_zeros(s, len)
	for i=1, len - #s do
		s = "0"..s
	end
	return s
end

function encrypt_hex(m, e, n)
	return bn.tohex(bn.powmod(hex2bn(m), e, n))
end

function decrypt_hex(x, d, n)
	return bn.tohex(bn.powmod(hex2bn(x), d, n))
end

function transform(url,public,private,modulus)
	local m = string2bn(url)
	local d = hex2bn(public)
	local e = hex2bn(private)
	local n = hex2bn(modulus)
	return m,d,e,n
end

function split_string(s)
	return string.sub(s, 1, #s/2), string.sub(s, #s/2 + 1, #s)
end

--[[
Return the private exponent of the private RSA key. If no parameter is given,
this function expects to find a file private_key.pem file in the
current directory.
Returns the private exponent as a bn's big integer.
]]
function initPrivExp(private_key_file)

	if private_key_file == nil then private_key_file = "private_key.pem" end
	
	local cmd = "openssl rsa -text -in "..private_key_file.."  2> /dev/null"
	local out = io.popen(cmd)

	local line = out:read()
	local exp = ""
	while line do
		if line:find'privateExponent:' then
			while not line:find'prime1:' do 
				exp = exp..line.."\n" 
				line= out:read() 
			end
		end
		line= out:read()
	end
	
	exp = string.sub(exp,17)
	exp = string.gsub(exp, "[:\n%s]","")
	
	return hex2bn(exp)
end

--[[
Return modulus of the private key. If no parameter is given,
this function expects to find a file private_key.pem file in the
current directory.
Returns the modulus as a bn's big integer.
--works only on *nix with OpenSSL library installed
]]
function initModulus(private_key_file)	
	if private_key_file == nil then private_key_file = "private_key.pem" end
	local cmd = "openssl rsa -in "..private_key_file.." -noout -modulus"
	local out = io.popen(cmd)
	line = out:read()
	return hex2bn(string.sub(line,9))
end

--[[
It extract the modulus from the given string representation
of the public RSA key. 
Thef format of the string is expected to be the same as the one
in output from 'openssl rsa' generation tool.
The current implementation writes the string on a temp file.
]]
function extractModulusFromPublicKey(keyAsString)
	--write the key on file
	local tmpFileName =  "/tmp/"..crypto.evp.new("sha1"):digest(math.random())..".pem" --io.tmpname()
	tmpFile = io.open(tmpFileName,"w")
	tmpFile:write(keyAsString) --check
	tmpFile:close()
	--extract the modulus from it
	local cmd = "openssl rsa -noout -modulus -pubin -in "..tmpFileName
	local out = io.popen(cmd)
	line = out:read()
	os.remove(tmpFileName)
	return string.sub(line,9)
end

function parse(file_path)
	local f = assert(io.open(file_path, "r"))
	local t = f:read("*a")
	f:close()
	return t
end

--[[
Generate a pair of RSA keys using openssl, 1024 bit, and return them as strings.
Return privk,pubk.
]]
function generate_rsa_keys_pair()
	local privk_file = "/tmp/"..crypto.evp.new("sha1"):digest(math.random().."priv")..".pem" --io.tmpname()	
	local pubk_file =  "/tmp/"..crypto.evp.new("sha1"):digest(math.random().."pub")..".pem" --io.tmpname()

	local ret=os.execute("openssl genrsa -out "..privk_file.." 1024 > /dev/null 2>&1")
	if ret~=0 then error("Can't generate private key on file "..privk_file) end
	ret = os.execute("openssl rsa -pubout -in "..privk_file.." -out "..pubk_file.." > /dev/null 2>&1")
    if ret~=0 then error("Can't generate public key on file "..pubk_file) end

	local privk = parse(privk_file)
	local pubk = parse(pubk_file)
	return privk,pubk
end

