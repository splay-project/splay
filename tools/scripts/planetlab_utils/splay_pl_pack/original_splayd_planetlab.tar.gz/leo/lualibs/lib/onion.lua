local rsa=require"rsa"
local misc=require"splay.misc"
local type=type
local math=math
local string=string
local crypto = require"crypto"
local io=io
local assert=assert
local ipairs=ipairs
local tonumber=tonumber
local log=require"splay.log"
local table=table
module("onion")
--module(..., package.seeall)

RSA_LENGTH = 1024
RSA_LENGTH_HEX = 256
PUBEXP = 0x10001
LAST_HOP="000000000000"
--[[
function hex2ip_port: converts a 12-hex-char (IP: 8 chars, Port=4 chars) 
chain into a IP address string and a port as integer:
]]
function hex2ip_port(h)
	local ip_hex = string.sub(h,1,8)
	local p_hex = string.sub(h,9,12)
	local ip_dec_t = {}	
	for i=1,7,2 do
		ip_dec_t[#ip_dec_t+1] = tonumber(string.sub(ip_hex,i,i+1),16)
	end
	local ip_dec=table.concat(ip_dec_t,".")	
	local port_dec = string.format("%04i", tonumber(p_hex,16))
	return ip_dec,tonumber(port_dec)
end

--[[
Encode ip/port pair in hexadecimal format.
]]
function ip_port_2hex(ip,port)
	local t = misc.split(ip,":")
	if #t==2 then ip = t[1]; port = t[2] end
	local octets = misc.split(ip,".")
	local hex_t={}
	for _,v in ipairs(octets) do hex_t[#hex_t+1]= string.format("%02X", v) end
	if port then
		hex_t[#hex_t+1] = string.format("%04X", tonumber(port))
	end
	return table.concat(hex_t)	
end


local function calculate_piece_size(hex)
	local total_size = (#hex)
	local number_pieces = math.ceil(total_size/(RSA_LENGTH_HEX-2))
	return math.ceil(total_size / number_pieces)
end


local function add_one_onion_layer(message_hex, nexthop_hex, modulus)
	local mixed = message_hex..nexthop_hex
	local enc_t = {}
	local piece_size = calculate_piece_size(mixed)
	while mixed ~= "" do
		local piece = "F"..string.sub(mixed, 1, piece_size)
		mixed = string.sub(mixed, piece_size + 1)
		local partial_enc = rsa.pad_hex_with_zeros(rsa.encrypt_hex(piece, PUBEXP, modulus), RSA_LENGTH_HEX)
		enc_t[#enc_t+1]=partial_enc
	end
	return table.concat(enc_t)	
end

--[[
Encrypt the given data with the specified key and the nexthop.
key : the public key
data: the content to encrypt, in hex format
nexthop: a node table {ip,port} or LAST_HOP
]]
function onion_encrypt(key,data,nexthop)
	local mod_hex= rsa.extractModulusFromPublicKey(key)
	local mod = rsa.hex2bn(mod_hex)	
	local message_hex = data
	local nexthop_hex=nil
	if (type(nexthop)=="table") then 
		assert(nexthop.ip, 'nexthop.ip field is invalid')
		assert(nexthop.port, 'nexthop.port field is invalid')
		nexthop_hex = ip_port_2hex(nexthop.ip, nexthop.port)
	elseif nexthop==LAST_HOP then
			nexthop_hex=nexthop
	else
		error("Invalid nexthop value: "..nexthop) 
	end
	local onion = add_one_onion_layer(message_hex, nexthop_hex, mod)
	return onion
end
--[[
Decrypt the data with the specified private key. 
If the decoded nexthop is "000000000000", the function
returns the plaintext message.
If not, the function returns the triplet data,ip_nexthop,port_nexthop. 
]]
function onion_decrypt(key,data)
	--write key to file
	local privk_file = "/tmp/"..crypto.evp.new("sha1"):digest(math.random().."temp_file")..".pem" 
	local out = assert(io.open(privk_file, "w"))
	out:write(key)
 	out:close()	
	--extract rsa elements
	local priv_exp = rsa.initPrivExp(privk_file)
	local priv_modulus = rsa.initModulus(privk_file)	
	local decrypted_t = {}
	local number_parts = #data / RSA_LENGTH_HEX
	for i= 1, number_parts do
		local part = string.sub(data, 1, RSA_LENGTH_HEX)
		local dec_part = rsa.decrypt_hex(part, priv_exp, priv_modulus)
		local F_pos = string.find(dec_part, "F")
		decrypted_t[#decrypted_t+1]=string.sub(dec_part, F_pos+1)
		data = string.sub(data, RSA_LENGTH_HEX + 1)
	end	
	local decrypted=table.concat(decrypted_t)
	local ris = string.sub(decrypted, 1, #decrypted-12)
	local nexthop_hex = string.sub(decrypted, #decrypted-11)

	if nexthop_hex == LAST_HOP then
		return rsa.hex2string(ris)
	else 
		local nexthop_ip, nexthop_port = hex2ip_port(nexthop_hex)
		return ris, nexthop_ip, nexthop_port
	end
end

--encrypt the message with the given key
function encrypt(message, key) 
	local message_hex=rsa.string2hex(message)
	local mod_hex= rsa.extractModulusFromPublicKey(key)
	local mod = rsa.hex2bn(mod_hex)	
	local enc_t = {}
	local piece_size = calculate_piece_size(message_hex)
	while message_hex ~= "" do
		local piece = "F"..string.sub(message_hex, 1, piece_size)
		message_hex = string.sub(message_hex, piece_size + 1)
		local partial_enc = rsa.pad_hex_with_zeros(rsa.encrypt_hex(piece, PUBEXP, mod), RSA_LENGTH_HEX)
		enc_t[#enc_t+1]=partial_enc
	end
	return table.concat(enc_t)
end
--encrypt the message (in HEX format) with the given key
function decrypt(message_hex, key)
	local privk_file = "/tmp/"..crypto.evp.new("sha1"):digest(math.random().."temp_file_to_decrypt")..".pem"
	local out = assert(io.open(privk_file, "w"))
	out:write(key)
 	out:close()
	local priv_exp = rsa.initPrivExp(privk_file)
	local priv_modulus = rsa.initModulus(privk_file)	
	local decrypted_t = {}
	local number_parts = #message_hex / RSA_LENGTH_HEX
	for i= 1, number_parts do
		part = string.sub(message_hex, 1, RSA_LENGTH_HEX)
		local dec_part = rsa.decrypt_hex(part, priv_exp, priv_modulus)
		local F_pos = string.find(dec_part, "F")
		decrypted_t[#decrypted_t+1] = string.sub(dec_part, F_pos+1)
		message_hex = string.sub(message_hex, RSA_LENGTH_HEX + 1)
	end
	return rsa.hex2string(table.concat(decrypted_t))
end

--sign the message with the given private key
function sign(message,privk,job_ref)
	local message_hex=rsa.string2hex(message)
	local privk_file = "/tmp/"..crypto.evp.new("sha1"):digest(math.random().."temp_file_to_sign")..".pem"
	local out = assert(io.open(privk_file, "w"))
	out:write(privk)
 	out:close()	
	local priv_exp = rsa.initPrivExp(privk_file)
	assert(priv_exp)
	local priv_modulus = rsa.initModulus(privk_file,job_ref)
	assert(priv_modulus)
	local signed_t = {}
	local piece_size = calculate_piece_size(message_hex)
	while message_hex ~= "" do
		local piece = "F"..string.sub(message_hex, 1, piece_size)
		message_hex = string.sub(message_hex, piece_size + 1)
		local partial_signed = rsa.pad_hex_with_zeros(rsa.encrypt_hex(piece, priv_exp, priv_modulus), RSA_LENGTH_HEX)
		signed_t[#signed_t+1]=partial_signed
	end
	return table.concat(signed_t)
end

