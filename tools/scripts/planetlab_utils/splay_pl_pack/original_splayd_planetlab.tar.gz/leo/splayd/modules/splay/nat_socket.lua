--[[
	Splayd
	Copyright 2010 - Valerio Schiavoni (University of Neuchâtel)
	http://www.splay-project.org
]]

--[[
This file is part of Splayd.

Splayd is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option)
any later version.

Splayd is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
Splayd.  If not, see <http://www.gnu.org/licenses/>.
]]
--[[

USAGE:

socket = require"socket.core"
ns = require"splay.nat_socket"
ns.init(settings)
socket = ns.wrap(socket)
require"splay.base"

The function udp.receive() uses receivefrom() behind-the-scenes to get the
remote peer's ip and port
(how to be more efficient?)

The special key 'ANY' in nat_rules models the open-for-everyone state. Only used for
(Full)CONE nats.

TODO:to properly emulate SYM NAT, it is required to know the outgoing port chosen
by the NAT to send the datagram UDP or to establish the connection (TCP). How to do that?
TODO: some entries could be GC'ed after some time.
]]

local string = require"string"
local misc=require"splay.misc"
local log = require"splay.log"

local tostring = tostring
local setmetatable = setmetatable
local pairs=pairs
local print=print
local time=os.time
local date=os.date
local getenv=os.getenv
local tonumber=tonumber
local assert=assert

module("splay.nat_socket")

--[[ DEBUG ]]--
l_o = log.new(3, "[".._NAME.."]")

-- vars
local nat_rules={}

--[[ CONFIG ]]--
local nat_type ="NONE" --possible values: NONE/CONE/RES_CONE/PORT_RES_CONE
local nat_ttl = 180

local init_done = false
function init(settings)
		if not init_done then
				init_done = true
				if not settings then return false, "no settings" end				
				nat_type=settings.nat_type or "NONE"
				nat_ttl = settings.nat_ttl or nat_ttl ---in seconds
				return true
		else
			return false, "init() already called"
		end
end

--[[
Wrap an UDP socket to keep mappings between outgoing/incoming datas, their source/origins
and associated timings.
]]
local function udp_sock_wrapper(sock)

	local new_sock = {}

	-- This socket is called with ':', so the 'self' refer to socket but, in
	-- the call, self is the wrapping table, we need to replace it by socket.
	local mt = {
		__index = function(table, key)
			return function(self, ...)
				--l_o:debug("udp."..key.."()")
				return sock[key](sock, ...)
			end
		end,
		__tostring = function()
			return "#NATS (UDP): "..tostring(sock)
		end}

	setmetatable(new_sock, mt)

	-- Restricted methods related to incoming/outgoing datas --

	if sock.receive then
		new_sock.receive = function(self, ...)
			--l_o:debug("udp.receive()")			
			local data, ip, port = sock:receivefrom(...)
			--print("receive",data,ip,port)
			accept_datagram=false
			local now=time()
			
			if nat_type=="CONE" and nat_rules["ANY"] and (now - nat_rules["ANY"]) <= nat_ttl then
				nat_rules["ANY"]=now
				accept_datagram = true

			elseif nat_type=="RES_CONE" and nat_rules[ip] and (now - nat_rules[ip]) <= nat_ttl then
				nat_rules[ip] = now
				accept_datagram = true

			elseif nat_type=="PORT_RES_CONE" and nat_rules[ip..":"..port] and (now - nat_rules[ip..":"..port]) <= nat_ttl then
				nat_rules[ip..":"..port] = now
				accept_datagram = true
			end

			if not accept_datagram then
				return nil,'timeout'
			else
				return data
			end
			
		end
	end

	if sock.receivefrom then
		new_sock.receivefrom = function(self, ...)
			--l_o:debug("udp.receivefrom()")
			local data, ip, port = sock:receivefrom(...)
			--print("receivefrom",data,ip,port)
			if not data then
				return nil,'timeout'
			end
			assert(ip)
			assert(port)
			
			accept_datagram=false
			local now=time()
			
			if nat_type=="CONE" and  nat_rules["ANY"] and (now - nat_rules["ANY"]) <= nat_ttl then
				nat_rules["ANY"]=now
				accept_datagram = true
			
			elseif nat_type=="RES_CONE" and nat_rules[ip] and (now - nat_rules[ip]) <= nat_ttl then
				nat_rules[ip] = now
				accept_datagram = true
				
			elseif nat_type=="PORT_RES_CONE" and nat_rules[ip..":"..port] and (now - nat_rules[ip..":"..port] ) <= nat_ttl then
				nat_rules[ip..":"..port] = now
				accept_datagram = true
			end
			
			if not accept_datagram then
				return nil,'timeout'
			else
				return data, ip, port
			end
		end
	end
	
	if sock.send then
		new_sock.send = function(self, data)
			--l_o:debug("udp.send()")
			local ip,port = sock:getsockname()
			--print("send "..ip..":"..port)
			local now=time()
			
			if nat_type=="CONE" then
				--create or update the nat rule toward anynode
				nat_rules["ANY"] = now
			elseif nat_type=="RES_CONE" then
				--create or update the nat rule toward this specific IP
				nat_rules[ip] = now
			elseif nat_type=="PORT_RES_CONE" then
				--create or update the nat rule toward this specific IP+port
				nat_rules[ip..":"..port] = now
			end

			--n,status
			return sock:sendto(data, ip, port)
		end
	end

	if sock.sendto then
		
		new_sock.sendto = function(self, data, ip, port)
			--l_o:debug("udp.sendto()")
			--print("sendto,  "..ip..":"..port)
			local now=time()
			if nat_type=="CONE" then
				--create or update the nat rule toward anynode
				nat_rules["ANY"] = now
			elseif nat_type=="RES_CONE" then
				--create or update the nat rule toward this specific IP
				nat_rules[ip] = now
			elseif nat_type=="PORT_RES_CONE" then
				--create or update the nat rule toward this specific IP+port
				nat_rules[ip..":"..port] = now
			end
			--n,status
			return sock:sendto(data, ip, port)
		
		end
	end
	
	--this function doesn't generate any traffic on the network
	--turns the socket from unconnected to connected, to gain 30% perfs
	if sock.setpeername then
		new_sock.setpeername = function(self, ip, port)
			return sock:setpeername(ip, port)
		end
	end	
	--this function doesn't generate any traffic on the network
	if sock.setsockname then
		new_sock.setsockname = function(self, address, port)
			return sock:setsockname(address, port)
		end
	end
	--this function doesn't generate any traffic on the network
	if sock.close then
		new_sock.close = function(self)
			sock:close()
		end
	end
	return new_sock
end

--[[
 Create a NAT emulation layer around a true tcp socket.

 RFC for TCP-friendly NATs: http://tools.ietf.org/html/rfc5382#section-8

 This implementation won't support mapping reuse, that is a new mapping is created
 for every new internally initiated connection.

 This implementation allows unlimited number of mapping rules. If rules have to be
 collected, there are suggested values to relinquish mappings (min 2h4min of inactivity). 
 See http://tools.ietf.org/html/rfc5382#section-5 for details.

 This implementation doesn't support hair-pinning.
]]
local function tcp_sock_wrapper(sock)

	local new_sock = {}

	-- This socket is called with ':', so the 'self' refer to socket but, in
	-- the call, self is the wrapping table, we need to replace it by socket.
	local mt = {
		__index = function(table, key)
			return function(self, ...)
				--l_o:debug("tcp."..key.."()")
				return sock[key](sock, ...)
			end
		end,
		__tostring = function()
			return "#NATS (TCP): "..tostring(sock)
		end}

	setmetatable(new_sock, mt)

	if sock.receive then
		new_sock.receive = function(self, pattern, prefix)
			--l_o:debug("tcp.receive()")
			
			local ip,port=sock:getpeername()
			local now=time()
			if nat_type=="CONE" then
				--create or update the nat rule toward anynode
				nat_rules["ANY"] = now
			elseif nat_type=="RES_CONE" then
				--create or update the nat rule toward this specific IP
				nat_rules[ip] = now
			elseif nat_type=="PORT_RES_CONE" then
				--create or update the nat rule toward this specific IP+port
				nat_rules[ip..":"..port] = now
			end
			
			local data, msg, partial = sock:receive(pattern, prefix)
		
			return data, msg, partial
		end
	end
	
	if sock.send then
		new_sock.send = function(self, data, start, stop)
			--l_o:debug("tcp.send()")
			
			local ip,port=sock:getpeername()
			local now=time()
			if nat_type=="CONE" then
				--create or update the nat rule toward anynode
				nat_rules["ANY"] = now
			elseif nat_type=="RES_CONE" then
				--create or update the nat rule toward this specific IP
				nat_rules[ip] = now
			elseif nat_type=="PORT_RES_CONE" then
				--create or update the nat rule toward this specific IP+port
				nat_rules[ip..":"..port] = now
			end
			
			
			local n, status, last = sock:send(data, start, stop)

			return n, status, last
		end
	end

	if sock.connect then
		new_sock.connect = function(self, ip, port)
			--l_o:debug("tcp.connect("..host..", "..tostring(port)..")")
			assert(ip,"IP to sock:connect(..) is nil")
			assert(port,"Port to sock:connect(..) is nil")
			
			local now=time()
			if nat_type=="CONE" then
				--create or update the nat rule toward anynode
				nat_rules["ANY"] = now
			elseif nat_type=="RES_CONE" then
				--create or update the nat rule toward this specific IP
				nat_rules[ip] = now
			elseif nat_type=="PORT_RES_CONE" then
				--create or update the nat rule toward this specific IP+port
				nat_rules[ip..":"..port] = now
			end
			
			local s, m = sock:connect(ip, port)
			
			return s, m
		end
	end
	
	--this function doesn't generate any traffic on the network
	if sock.bind then
		new_sock.bind = function(self, address, port, backlog)
			--l_o:debug("tcp.bind("..address..", "..tostring(port)..")")
			return sock:bind(address, port, backlog)
		end
	end

	--[[
	Closing a socket doesn't affect the mapping rules
	]]
	if sock.close then
		new_sock.close = function(self)
			--l_o:debug("tcp.close()")

			if not sock:getsockname() then
				l_o:notice("Closing an already closed socket.")
			else
				--l_o:debug("Peer closed, total TCP sockets: "..total_tcp_sockets)
				sock:close()
			end
		end
	end

	-- A complete accept function that return a client wrapper
	-- recursively (not directly in tcp_sock_wrapper() because we
	-- can't call the same function internally)
	if sock.accept then
		new_sock.accept = function(self)
			--l_o:debug("tcp.accept()")
			
			-- We must accept the client first, if not, socket.select() will
			-- select it every time we don't take it, but if the number of
			-- socket is too high, we will close the socket immediately.
			local s, err = sock:accept()
					
			if not s then return nil, err end
			
			local accept_connection = false
			local now=time()
			
			local ip,port = s:getpeername()
			
			if nat_type=="NONE" then
				return tcp_sock_wrapper(s)
			
			elseif nat_type=="CONE" and nat_rules["ANY"] and (now - nat_rules["ANY"]) <= nat_ttl then
				accept_connection = true
				nat_rules["ANY"] = now
			
			elseif nat_type=="RES_CONE" and nat_rules[ip] and (now - nat_rules[ip]) <= nat_ttl then
				accept_connection = true
				nat_rules[ip] = now
			
			elseif nat_type=="PORT_RES_CONE" and  nat_rules[ip..":"..port] and (now - nat_rules[ip..":"..port] ) <=nat_ttl then
				nat_rules[ip..":"..port] = now
				accept_connection = true
			end
			
			if accept_connection then 	return tcp_sock_wrapper(s)
			else return nil, err end
			
			--l_o:debug("New peer: "..s:getpeername())
			return tcp_sock_wrapper(s)
		end
	end
	
	return new_sock
end


function wrap(sock)
	if string.find(tostring(socket), "#NATS") then
		l_o:warn("Trying to NATify an already NAT socket "..tostring(socket))
		return socket
	end

	-- The NATted Socket(tm)
	local natted_sock = {}
	
	local mt = {
		-- With __index returning a function instead of a table, the inside table
		-- (sock) can't be taken from the metatable.
		--mt.__index = sock
		__index = function(table, key)
			--l_o:debug("sock."..key.."()")
			return sock[key]
		end,
		__tostring = function()
			return "#NATS: "..tostring(sock) 
		end
	}

	setmetatable(natted_sock, mt)
	
	--[[
	Return the number of registered nat_rules
	]]
	natted_sock.nat_stats = function()
		return misc.size(nat_rules)
	end
	
	natted_sock.nat_infos = function()
		
		local infos="NAT type:"..nat_type.."\n -- NAT rules --\n"
		infos=infos.."IP:port - Active Since\n"
		for k,v in pairs(nat_rules) do
			local h=date("%X-%x",v)
			infos=infos..k.." "..h.."\n"
		end
		return infos
	end
	
	natted_sock.udp = function()
		--l_o:debug("Creating UDP NAT socket")
		local sudp, err = sock.udp()
		
		if not sudp then
			return nil, err
		else
			return udp_sock_wrapper(sudp)
		end
	end
	
	natted_sock.tcp = function()
		--l_o:debug("tcp()")

		local stcp, err = sock.tcp()
		if not stcp then
			return nil, err
		else
			return tcp_sock_wrapper(stcp)
		end
	end
	
	return natted_sock
end