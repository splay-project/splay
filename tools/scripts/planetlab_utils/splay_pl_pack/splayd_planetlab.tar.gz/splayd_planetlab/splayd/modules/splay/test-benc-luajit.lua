-- convert big or small number in scientific notation into a decimal string
function to_dec_string(s)
	s = tostring(s)
	local start, stop = string.find(s, "e", 1, true)
	-- not scientific
	if not start then return s end

	local positif = true
	if string.sub(s, 1, 1) == "-" then
		s = tonumber(string.sub(s, 2))
		positif = false
	end

	local t = split(s, "e")
	local m, e = t[1], t[2]
	local t = split(m, ".")
	if t[2] then
		m = t[1]..t[2]
	end

	if string.sub(e, 1, 1) == "-" then
		e = tonumber(string.sub(e, 2))
		for i = 1, e - 1 do
			m = "0"..m
		end
		m = "0."..m
	else
		e = tonumber(e) - #m + 1
		for i = 1, e do
			m = m.."0"
		end
	end
	if not positif then m = "-"..m end
	return m
end

function encode(data)
	local t = type(data)

	if t == 'table' then -- list(array) or hash
		local i = 1
		local list = true
		for k, v in pairs(data) do
			if k ~= i then
				list = false
				break
			end
			i = i + 1
		end
		local out = ''
		if list then
			out = 'l'
			for k, v in pairs(data) do
				out = out..encode(v)
			end
		else -- hash
			out = 'd'
			for k, v in pairs(data) do
				out = out..encode(k)..encode(v)
			end
		end
		return out..'e'
	elseif t == 'string' then
		return #data..':'..data
	elseif t == 'number' then
		-- we need to convert scientific notation to decimal
		return 'i'..misc.to_dec_string(data)..'e' 
	elseif t == 'nil' then -- extension of benc
		return 'n'
	elseif t == 'boolean' then -- extension of benc
		if data then
			return 't'
		else
			return 'f'
		end
	end
end

data_sizes={1000,10000,100000,1000000}

print("Bench nested arrays with fixed-size string")
for k,v in pairs(data_sizes) do
	
	local gen="a"
	for i=1,(v/100) do --to avoid stackoverlow
		gen={gen}
	end
	
	start=os.clock()
	enc_data=encode(gen)
	print((v/100), os.clock()-start)
end